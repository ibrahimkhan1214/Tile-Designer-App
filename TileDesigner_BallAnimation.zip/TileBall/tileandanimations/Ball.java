/*
 * ****************************************************************************************
 * Progammer: ibrahim khan(z1837663) && Noman Naveed(z1857187)
 * 
 * Date Created: April 25th, 2021
 *
 * Purpose: adding an animation to run in the background thread of the tile design application.
 * 
 * Working:- 
 * =>Carrying on from the Tile design app in this project we are adding an EAST panel
 * =>East panel will have a bouncing ball animation that will run in background thread
 * =>We have added three new file to the tite design application.
 * 1:Ball.java (for the traits of the balls)
 * 2:AnimationPanel(to setup the layout of the animations panel)
 * 3:BallAnimations(to dictate the animations of the balls)
 ******************************************************************************************
 */

package tileandanimations;
import java.awt.*;

class Ball {
    //variables to store ball traits
    public Color color;
    public int radius;
    public int x, y;
    private int dx, dy;
    private int rangex, rangey;

    public static Dimension d;   //variable to store the dimensions of the balls
    /*
    Ball constructor takes the following arguments:
    ->color of the ball
    ->center point of the ball circle (x,y)
    ->radius of the ball
    */
    public Ball(Color color,int x,int y,int radius)
    {
        //initialize traits of the balls
        this.color=color;
        this.x=x;
        this.y=y;
        this.radius=radius;
        rangex=x+radius;                           // This is for border collision detection
        rangey=y+radius;                           // This is for border collision detection
    }

    //This method will make the balls move in the panel
    public void move()
    {
        //if range of radius of circle is greater than that of the boundry then keep moving
        if((rangex+dx <= d.width) && (rangex+dx >= 50))
            x += dx;              //keep moving
        else
        {
            dx *= -1;             //if the ball hits the boundary change the direction
            x += dx;              //add change to x coordinate
        }
        rangex=x+radius;          //update the range in X 
        //if the radius of the circle is greater than boundary(its moving in the panel height)
        if((rangey+dy <= d.height) && (rangey+dy >= 50))
        {
            y+=dy;                 //keep moving
        }
        else
        {
            dy*=-1;                //otherwise change the direction so the ball bounces back
            y+=dy;                 //update y coordinate
        }
        rangey=y+radius;//update range in Y 

    }

    //This function sets the movements of the balls
    public void setMovement(int changex,int changey)
    {
        this.dx=changex;
        this.dy=changey;
    }

    //This method will draw the balls
    public void draw(Graphics graphics)
    {
        graphics.setColor(color);
        graphics.fillOval(d.height/2, d.width/2, radius*2, radius*2);
    }
}