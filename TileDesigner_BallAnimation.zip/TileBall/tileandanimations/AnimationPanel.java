/*
 * ****************************************************************************************
 * Progammer: ibrahim khan(z1837663) && Noman Naveed(z1857187)
 * 
 * Date Created: April 25th, 2021
 *
 * Purpose: adding an animation to run in the background thread of the tile design application.
 * 
 * Working:- 
 * =>Carrying on from the Tile design app in this project we are adding an EAST panel
 * =>East panel will have a bouncing ball animation that will run in background thread
 * =>We have added three new file to the tite design application.
 * 1:Ball.java (for the traits of the balls)
 * 2:AnimationPanel(to setup the layout of the animations panel)
 * 3:BallAnimations(to dictate the animations of the balls)
 ******************************************************************************************
 */

package tileandanimations;
import javax.swing.*;
import java.awt.*;


public class AnimationPanel extends BallAnimation
{
     Dimension d = new Dimension(350,350);//set dimension

    //Ballpane constructor
    public AnimationPanel()
    {
        BallAnimation animation = new BallAnimation(); 
        //Setting the layout for ball animations panel
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createLineBorder(Color.BLACK));
        setBackground(Color.WHITE);
        JButton start=new JButton("Start");                //creating a button object for start button
        JButton stop=new JButton("Stop");                  //creating the button object for stop button
        stop.setEnabled(false);

        //action listener for start button
        start.addActionListener( a -> {
            start.setEnabled(false);
            stop.setEnabled(true);
            animation.run();//call the run function
        });

        //action listener for stop button
        stop.addActionListener(a -> {
            start.setEnabled(true);
            stop.setEnabled(false);
            animation.stop();                              //calling the stop method to keep the balls halted initially
        });

        Ball.d=getSize();

        add(animation);                                      //add panel
        JPanel anim_button_panel=new JPanel();               //initialze button panel
        anim_button_panel.add(start);                        //add start button to the panel
        anim_button_panel.add(stop);                         //add stop button to the panel
        anim_button_panel.setBackground(Color.LIGHT_GRAY);   //Selecting the backGround color for the Animations Panel.
        add(anim_button_panel,BorderLayout.SOUTH);           //put buttons panel to the south of the animationPanel
    }
}
