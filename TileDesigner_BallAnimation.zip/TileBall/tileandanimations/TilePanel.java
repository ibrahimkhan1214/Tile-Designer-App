/*
 * ****************************************************************************************
 * Progammer: ibrahim khan(z1837663) && Noman Naveed(z1857187)
 * 
 * Date Created: April 25th, 2021
 *
 * Purpose: adding an animation to run in the background thread of the tile design application.
 * 
 * Working:- 
 * =>Carrying on from the Tile design app in this project we are adding an EAST panel
 * =>East panel will have a bouncing ball animation that will run in background thread
 * =>We have added three new file to the tite design application.
 * 1:Ball.java (for the traits of the balls)
 * 2:AnimationPanel(to setup the layout of the animations panel)
 * 3:BallAnimations(to dictate the animations of the balls)
 ******************************************************************************************
 */

package tileandanimations;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TilePanel extends JFrame
{
    //Declaring buttons for the tool bar
    private JButton patch1btn,patch2btn,patch3btn,patch4btn,patch5btn;    //tile design buttons
    private  final String[] names = {"pat1.gif","pat2.gif","pat3.gif","pat4.gif","pat5.gif"};
    public static Image[] images = new Image[5];   //This array is for the tile designs
    public static int selected = -1;               //this variable denotes the selected tile design
    private JToolBar tileToolBar;                  //This is the toolbar

    //contructor
    public TilePanel()
    {
        Dimension d=new Dimension(400,400);                 //setting dimensions
        setSize(700,500);                                   //setting the size of the panels
        setLayout(new BorderLayout());
        setResizable(false);                                //initializing the buttons 
        patch1btn=new JButton();                            
/*
Creating the buttons for all 5 tile designs and assigning them their respective values.
The values will be stored in the selected variable
This value will be used to draw the selected design onto the grid
*/
        patch1btn.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                selected=1;
            }
        });

        patch2btn=new JButton();
        patch2btn.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                selected=2;
            }
        });

        patch3btn=new JButton();
        patch3btn.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                selected=3;
            }
        });

        patch4btn=new JButton();
        patch4btn.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                selected=4;
            }
        });

        patch5btn=new JButton();
        patch5btn.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                selected=5;
            }
        });

        //Using the toolkit get the images to draw
        images[0]=(Image)Toolkit.getDefaultToolkit().getImage(names[0]);     //getting tile design at array location 0
        patch1btn.setSize(d);                                                //setting the size of the tile design
        patch1btn.setIcon(new ImageIcon(images[0]));                         //assigning the tile design to the button as an icon

        images[1]=(Image)Toolkit.getDefaultToolkit().getImage(names[1]);     //getting tile design at array location 1      
        patch2btn.setSize(d);                                                //setting the size of the tile design
        patch2btn.setIcon(new ImageIcon(images[1]));                         //assigning the tile design to the button as an icon

        images[2]=(Image)Toolkit.getDefaultToolkit().getImage(names[2]);     //getting tile design at array location 2
        patch3btn.setSize(d);                                                //setting the size of the tile design
        patch3btn.setIcon(new ImageIcon(images[2]));                         //assigning the tile design to the button as an icon

        images[3]=(Image)Toolkit.getDefaultToolkit().getImage(names[3]);     //getting tile design at array location 3
        patch4btn.setSize(d);                                                //setting the size of the tile design
        patch4btn.setIcon(new ImageIcon(images[3]));                         //assigning the tile design to the button as an icon

        images[4]=(Image)Toolkit.getDefaultToolkit().getImage(names[4]);     //getting tile design at array location 4
        patch5btn.setSize(d);                                                //setting the size of the tile design
        patch5btn.setIcon(new ImageIcon(images[4]));                         //assigning the tile design to the button as an icon


        tileToolBar=new JToolBar();                     //creating a Jtoolbar object
        tileToolBar.setLayout(new FlowLayout());        //setting the layout of the toolbar
        tileToolBar.setBackground(Color.LIGHT_GRAY);

        //adding tile design buttons to the toolbar
        tileToolBar.add(patch1btn);
        tileToolBar.add(patch2btn);
        tileToolBar.add(patch3btn);
        tileToolBar.add(patch4btn);
        tileToolBar.add(patch5btn);

        //adding the toolbar to the frame
        JPanel panel1=new JPanel();
        panel1.setSize(getHeight(), getWidth());
        panel1.setBackground(Color.BLUE);

        JPanel panel2=new JPanel();                 
        panel1.setLayout(new BorderLayout());
        panel1.add(tileToolBar,BorderLayout.NORTH);

        //adding the ball panel to the main panel
        MainPanel ballpanel = new MainPanel();
        panel1.add(ballpanel);
        panel2.setBackground(Color.BLACK);
        getContentPane().add(panel1,BorderLayout.WEST);     //setting the tile design panel to the west
        getContentPane().add(new AnimationPanel());         //adding ball animation panel to the east
    }
}
