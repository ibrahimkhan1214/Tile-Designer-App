/*
 * ****************************************************************************************
 * Progammer: ibrahim khan(z1837663) && Noman Naveed(z1857187)
 * 
 * Date Created: April 25th, 2021
 *
 * Purpose: adding an animation to run in the background thread of the tile design application.
 * 
 * Working:- 
 * =>Carrying on from the Tile design app in this project we are adding an EAST panel
 * =>East panel will have a bouncing ball animation that will run in background thread
 * =>We have added three new file to the tite design application.
 * 1:Ball.java (for the traits of the balls)
 * 2:AnimationPanel(to setup the layout of the animations panel)
 * 3:BallAnimations(to dictate the animations of the balls)
 ******************************************************************************************
 */

package tileandanimations;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Arrays;


public class MainPanel extends JPanel
{
    //Declaring a 2D array for Tile Designer
    private final int row=5,col=5;                     //A 5X5 grid
    private int[][] tiles=new int [row][col];          //two dimensional Array for tiles
    private int startX,startY,endX,endY;               //variables for grid dimensions
    private final int gridsquare=25;                   //Dimensions for the Grid Square
    private JButton reset;                             //Declaring the reset button here

    //constructor
    public MainPanel()
    {
        setLayout(new BorderLayout());
        reset=new JButton();                             //initialize button
        reset.setText("Reset");
        //adding action listener
        reset.addActionListener(new ActionListener()
        {
            //This function will set all of the grid locations to 0(Empty).
            @Override
            public void actionPerformed(ActionEvent e)
            {
                for(int i=0;i<row;i++)
                    Arrays.fill(tiles[i],0);
                repaint();
            }
        });
        
        JPanel panel= new JPanel();               //creating a JPanel object
        add(panel,BorderLayout.SOUTH);            //adding buttons panel to the south of the main panel
        panel.add(reset);                         //adding the reset button to the south panel.
        panel.setBackground(Color.LIGHT_GRAY); 
        //mouse Handler
        MouseAdapter mouseHandler;
        mouseHandler = new MouseAdapter() {

            //This method checks which grid location was clicked on to paint it.
            @Override
            public void mouseClicked(MouseEvent e)
            {

                //Getting x and y locations of where the click event occured
                int locationX=e.getX();
                int locationY=e.getY();

                //if the click event occured on the grid
                if((locationX>=startX && locationX <= endX) && (locationY >= startY && locationY <= endY))
                {
                    //go through all of the columns
                    for(int i=0;i<col;i++)
                    {
                        //find where the X cordinate of the click event lies
                        if((startX+(i*gridsquare)) <= locationX && (startX+((i+1)*gridsquare)) >= locationX)
                        {
                            locationX=i;
                            break;
                        }

                    }
                    //now go through rows
                    for(int j=0;j<row; j++)
                    {
                        //find where Y coordinate of the click event lies
                        if((startY+(j*gridsquare)) <= locationY && (startY+((j+1)*gridsquare)) >= locationY)
                        {
                            locationY=j;
                            break;
                        }

                    }
                    //set array with the found value
                    tiles[locationY][locationX]=TilePanel.selected;
                }

                //update the grid with the tile design on the specific grid location
                repaint();
            }

        };
        addMouseListener(mouseHandler);
    }

    //Overrided function to customize size
    @Override
    public Dimension getPreferredSize() {
        return new Dimension(300, 300);       //update dimensions
    }


    //when ever repaint() is called we call the paint component method as well.
    @Override
    protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        //get grid width and grid height
        int gridWidth=row*gridsquare;
        int gridHeight=col*gridsquare;
        //get starting point of grid
        startX=(getWidth()-gridWidth)/2;
        startY=(getHeight()-gridHeight)/2;
        //get ending point of grid
        endX=startX+(row*gridsquare);
        endY=startY+(col*gridsquare);


        //drawing grid
        for(int i=0; i < row;i++)
        {
            for(int j=0; j< col;j++)
            {
                int image=tiles[i][j];              //get value from 2D array
                //drawing image according to value
                switch(image)
                {
                    //empty tile
                    case -1:
                        graphics.drawRect(startX+(gridsquare*j),startY+(gridsquare*i),gridsquare,gridsquare);
                        break;
                    //empty tile
                    case 0:
                        graphics.drawRect(startX+(gridsquare*j),startY+(gridsquare*i),gridsquare,gridsquare);
                        break;
                    //paint image 1
                    case 1:
                        graphics.drawImage(TilePanel.images[image-1],startX+(gridsquare*j),startY+(gridsquare*i), gridsquare,gridsquare, this);
                        break;
                    //paint image 2
                    case 2:
                        graphics.drawImage(TilePanel.images[image-1],startX+(gridsquare*j),startY+(gridsquare*i), gridsquare,gridsquare, this);
                        break;
                    //paint image 3
                    case 3:
                        graphics.drawImage(TilePanel.images[image-1],startX+(gridsquare*j),startY+(gridsquare*i), gridsquare,gridsquare, this);
                        break;
                    //paint image 4
                    case 4:
                        graphics.drawImage(TilePanel.images[image-1],startX+(gridsquare*j),startY+(gridsquare*i), gridsquare, gridsquare, this);
                        break;
                    //paint image 5
                    case 5:
                        graphics.drawImage(TilePanel.images[image-1],startX+(gridsquare*j),startY+(gridsquare*i), gridsquare,gridsquare, this);
                        break;

                }

            }
        }
    }
}
