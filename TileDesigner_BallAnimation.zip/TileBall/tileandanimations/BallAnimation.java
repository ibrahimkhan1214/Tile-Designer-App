/*
 * ****************************************************************************************
 * Progammer: ibrahim khan(z1837663) && Noman Naveed(z1857187)
 * 
 * Date Created: April 25th, 2021
 *
 * Purpose: adding an animation to run in the background thread of the tile design application.
 * 
 * Working:- 
 * =>Carrying on from the Tile design app in this project we are adding an EAST panel
 * =>East panel will have a bouncing ball animation that will run in background thread
 * =>We have added three new file to the tite design application.
 * 1:Ball.java (for the traits of the balls)
 * 2:AnimationPanel(to setup the layout of the animations panel)
 * 3:BallAnimations(to dictate the animations of the balls)
 ******************************************************************************************
 */

package tileandanimations;

import java.awt.*;
import java.util.ArrayList;
import javax.swing.JPanel;

public class BallAnimation extends JPanel
{

    private ArrayList<Ball> balls=new ArrayList<>();    //ArrayList for balls
    Dimension d = new Dimension(350,350);               //Setting Dimensions
    private Thread thread=null;                         //Thread object

    //contructor
    public BallAnimation()
    {
        setLayout(new BorderLayout());                   //setting the layout for Ball animations

        //Adding balls to array list and assigning movement patterns
        balls.add(new Ball(Color.BLUE,d.height/2,d.width/2,10));
        balls.add(new Ball(Color.GREEN,d.height/2,d.width/2,80));
        balls.add(new Ball(Color.PINK,d.height/2,d.width/2,50));
        balls.add(new Ball(Color.ORANGE,d.height/2,d.width/2,20));
        balls.add(new Ball(Color.RED,d.height/2,d.width/2,60));
        balls.add(new Ball(Color.YELLOW,d.height/2,d.width/2,100));
        balls.get(0).setMovement(0, 5);
        balls.get(1).setMovement(0,-5);
        balls.get(2).setMovement(3,10);
        balls.get(3).setMovement(-5,0);
        balls.get(4).setMovement(5, 5);
        balls.get(5).setMovement(10,-5);
    }

    //Overrided paintComponent
    @Override
    protected void paintComponent(Graphics graphics)
    {
        super.paintComponent(graphics);
        Ball.d=getSize();                                //get dimension of animation panel
        //drawing balls
        for(Ball ball : balls)
        {
            graphics.setColor(ball.color);
            graphics.fillOval(ball.x, ball.y, ball.radius, ball.radius);
        }
    }

    //This method dictates is how the second thread functions.
    public final void run()
    {
        if(thread==null)
        {  
            //initialize thread and overide run method.
            thread=new Thread(()->
            {
                while(Thread.currentThread()==thread)     //if current thread is equal to thread
                {
                    for(Ball ball : balls)                //calling move method here to move the balls
                    {
                        ball.move();
                    }
                    repaint();                            //repaint panel
                    try
                    {
                        Thread.sleep(100);                //sleep for 100 milliseconds
                    }
                    catch(Exception e)
                    {
                        System.out.println(e.getMessage());
                    }
                }
            });
            thread.start();//start thread
        }
    }

    //This method will stop the balls movement
    public void stop()
    {
        thread = null;       //setting the thread to null stops the movement of the balls.
    }
}
