/*
 * ****************************************************************************************
 * Progammer: ibrahim khan(z1837663) && Noman Naveed(z1857187)
 * 
 * Date Created: April 25th, 2021
 *
 * Purpose: adding an animation to run in the background thread of the tile design application.
 * 
 * Working:- 
 * =>Carrying on from the Tile design app in this project we are adding an EAST panel
 * =>East panel will have a bouncing ball animation that will run in background thread
 * =>We have added three new file to the tite design application.
 * 1:Ball.java (for the traits of the balls)
 * 2:AnimationPanel(to setup the layout of the animations panel)
 * 3:BallAnimations(to dictate the animations of the balls)
 ******************************************************************************************
 */

package tileandanimations;
import javax.swing.*;

/*
This is the main class which will run the program.
Main class will only create an object of the Tile panel and display it.
I am using the show() method here for display.
*/

 public class Main {

    public static void main(String [] args)
    {
        TilePanel TilePanel=new TilePanel();         //create TilePanel object
        TilePanel.show();                            //display the Tile panel
        TilePanel.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);   //exit the program when closed. This is simply just a close condition.
    }
}
